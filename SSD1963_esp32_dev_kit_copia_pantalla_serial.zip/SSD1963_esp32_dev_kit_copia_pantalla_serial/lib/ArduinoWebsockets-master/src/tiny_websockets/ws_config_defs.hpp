#pragma once

#define _WS_CONFIG_NO_TRUE_RANDOMNESS
#define _WS_BUFFER_SIZE 512