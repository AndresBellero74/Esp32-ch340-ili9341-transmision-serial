
// This is the command sequence that initialises the ILI9327 driver
//
// This setup information uses simple 8 bit SPI writecommand() and writedata() functions
//
// See ST7735_Setup.h file for an alternative format

#if defined (ILI9327_DRIVER)
{
  writecommand(0xB0); // 
  writedata(0x01);
  writedata(0x00);

  writecommand(0xC1); // Display timings
  writedata(0x04);
  writedata(0x10);
  writedata(0x02);
  writedata(0x02);

  writecommand(0xC0); // Panel Drive
  writedata(0x06);
  writedata(0x00);
  writedata(0x35);
  writedata(0x00);
  writedata(0x00);
  writedata(0x01);
  writedata(0x02);

  writecommand(0xC5); // Frame Rate
  writedata(0x01);
  writedata(0x04);
 
  writecommand(0xD2); // Power Settings
  writedata(0x02);
  writedata(0x01);
  writedata(0x04);

  writecommand(0xCA); //GGT LUT
  writedata(0x01);
  writedata(0x00);

  writecommand(0xEA); // Gamma Function
  writedata(0x01);
  writedata(0x80);

  writecommand(ILI9327_DISPON); //Display on

}

#elif defined (ILI9327_2_DRIVER) // Alternative init sequence, see https://github.com/Bodmer/TFT_eSPI/issues/1172
{


}
#endif