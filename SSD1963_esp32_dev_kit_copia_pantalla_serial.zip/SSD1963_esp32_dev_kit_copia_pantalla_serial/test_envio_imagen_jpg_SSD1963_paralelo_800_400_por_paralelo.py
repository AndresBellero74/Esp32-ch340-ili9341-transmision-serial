#import cv2
import time
from PIL import Image
import pyautogui
from pynput import keyboard as kb
import array
import serial

lon = 0
puerto = "COM13" # tipico en windows X= un entero positivo
baudrate = 9600 #(o el baudrate adecuado/usado en putty)
data = ""
def color565(r, g, b):
    return (r & 0xf8) << 8 | (g & 0xfc) << 3 | b >> 3

def Draw_BMP(strFile):
    def lebytes_to_int(bytes):
        n = 0x00
        while len(bytes) > 0:
            n <<= 8
            n |= bytes.pop()
        return int(n)
    f = open(strFile, 'rb')
    img_bytes = list(bytearray(f.read(54)))
    if img_bytes:
        # Leo el archivo BMP
        assert img_bytes[0:2] == [66, 77], "Not a valid BMP file"
        assert lebytes_to_int(img_bytes[30:34]) == 0, \
            "Compression is not supported"
        assert lebytes_to_int(img_bytes[28:30]) == 24, \
            "Only 24-bit colour depth is supported"

        start_pos = lebytes_to_int(img_bytes[10:14])
        end_pos = start_pos + lebytes_to_int(img_bytes[34:38])

        width = lebytes_to_int(img_bytes[18:22])
        height = lebytes_to_int(img_bytes[22:26])
        contador = 0
        tamaño = (end_pos - start_pos)
        
#     while (contador < tamaño):
#        pixel_data = img_bytes[start_pos:end_pos]
#        data = pixel_data
        contador = 0
        data = ""
        print(height, width)
        print(tamaño)
        ser = serial.Serial(port=puerto, baudrate=baudrate, timeout=1)
        ser.close()
        ser.open()
        time.sleep(1)
        for y in range(height):
             for x in range(width):
                 contador = contador + 2
                 img_bytes = list(bytearray(f.read(3)))
                 r = img_bytes[0]
                 g = img_bytes[1]
                 b = img_bytes[2]
                 colorArmado = color565(b, g, r)
                 #print(colorArmado)
                 byte1 = int(((colorArmado / 256) - int(colorArmado / 256)) * 256)
                 byte0 = int(colorArmado / 256)
                 #print (byte0, byte1)
                 strByte0 = str(hex(byte0))
                 strByte1 = str(hex(byte1))
                 data = data + strByte0.replace("0x", "") + strByte1.replace("0x", "")
                 data = data.upper()
                 if len(data) == 1600:  #len(data)
                     pasaje = ser.write(data.encode())
                     #ser.write(b"Hola soy el dios del verano")
                     print(data)
                     time.sleep(1)
                     data = ""
                     raw_string_b = ser.readline()
                     raw_string_s = raw_string_b.decode('utf-8')
                     print (raw_string_s)
                 #print(colorArmado, r, g, b, "pos:",y, x)        
                 #display.pixel(x, y,colorArmado )
        #time.sleep(10)
        ser.close()
        return tamaño
    
def test(): 
    count = 0
    while count < 5000:
        screenshot = pyautogui.screenshot()
        # Guardar imagen.
        screenshot.save("foto.png")
        #cv2.imwrite("foto.png", frame)
        im = Image.open('foto.png')
        size = 320, 240
        im.thumbnail(size)
        new_im = im.resize(size)
        #new_im.save('foto.bmp')
        new_im.save('foto.jpg',"JPEG",dpi=[300,300],quality=40)
        print("Foto tomada correctamente")
        # Write character 'A' to serial port
        archivo = open("foto.jpg", "rb")
        #indice = 0
        ser = serial.Serial(port=puerto, baudrate=baudrate, timeout=100)
        ser.close()
        ser.open()
        byteArchivo = list(bytearray(archivo.read()))
        longitud = len(byteArchivo) - 1 
        data = ""
        for i in range(longitud):
            strByte0 = str(hex(byteArchivo[i]))
            strByte1 = strByte0.replace("0x", "")
            largo = len(strByte1)
            if (largo == 1):
                strByte1 = "0" + strByte1
            data = data + strByte1
        data = data.upper()
        pasaje = ser.write(data.encode())
        print(longitud, data)
        archivo.close()
        ser.close()
        #veces = int(longitud / 30000 + 1)
        # reabro para poder leerlo de a bloques
        #archivo = open("foto.bmp", "rb")
        #lon = Draw_BMP('foto.bmp')
        #vueltas = 1
        #while vueltas <= veces:
        #    print("longitud de datos")
        #    print(lon)
        #    vueltas = vueltas + 1
        #    #env_Serial()
        #    data = ""
            
        #archivo.close()
        time.sleep(1)
        count += 1  

test()

#cam = cv2.VideoCapture(0,cv2.CAP_DSHOW)

#cam.set(cv2.CAP_PROP_FRAME_WIDTH, 240)
#cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

#def pulsa(key):
#    print(str(key))
#    check, frame = cam.read()

#    cv2.imshow('video', frame)

#    key = cv2.waitKey(1)
#if key == kb.KeyCode.from_char('x'):
#        exit
#    if key == kb.KeyCode.from_char('c'):
#       leido, frame = cam.read()
#        # Capturar pantalla.

    
        
#with kb.Listener(pulsa) as escuchador:
#    escuchador.join()
